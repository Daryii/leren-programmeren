from RobotArm import RobotArm

robotArm = RobotArm('exercise 2')

robotArm.speed = 3

robotArm.grab()
for i in range (9):
    robotArm.moveRight()
robotArm.drop()
for z in range (5):
    robotArm.moveLeft()
robotArm.grab()
for x in range(5):
    robotArm.moveRight()
robotArm.drop()
for z in range (2):
    robotArm.moveLeft()
robotArm.grab()
for z in range (2):
    robotArm.moveRight()
robotArm.drop()



robotArm.wait()